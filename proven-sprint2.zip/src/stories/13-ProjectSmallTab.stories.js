import React from 'react';
import ProjectSmallTab from "../comps/ProjectSmallTab";
import "../App.scss";

export default {
    title: "ProjectSmallTab",
    component: ProjectSmallTab
}

export const defaultProjectTab= () => {
    return <ProjectSmallTab />
};
