import React from 'react';
import logo from './logo.svg';
import './App.scss';
import Main from "./pages/Main";

function App() {
  return (
    <Main/>
  );
}

export default App;
