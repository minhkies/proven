import React,{useState} from "react";
import Header from "../../../comps/Header";
import FormContainer from "../../../comps/FormContainer";
import InputField from "../../../comps/InputField";
import 'simplebar/dist/simplebar.min.css';
import CategoryBtn from "../../../comps/CategoryBtn";
import BottomBtnBar from "../../../comps/BottomBtnBar";

/**
 * @return {boolean}
 */

export function infoDisplay(title, content){
    return <div className={"info-display-container"}>
        <p className={"preview-info-title"}>{title}</p>
        <p className={"preview-info-content"}>{content}</p>
    </div>
}

/**
 * @return {boolean}
 */

export default function Preview({value, setValue, setNextStep, completedStep, setCompletedStep, stepRefresh, setStepRefresh}) {
    let currentData;
    if(sessionStorage.getItem("currentData")) {
        currentData = JSON.parse(sessionStorage.getItem("currentData"));
        return (<div className={"preview-container"}>
            <Header
                headingTxt={"Project Overview"}
                subTxt={"Please review project posting. Click the ‘edit’ icon to make any changes."}
                marginTop={false}
            />
            <FormContainer formHeading={"Project Details"} col={3}>
                <div className={"preview-details-container"}>
                    {infoDisplay("Project Details", currentData.projectDetails.name)}
                    {infoDisplay("Project ID", currentData.projectDetails.projectId)}
                    {infoDisplay("Description", currentData.projectDetails.description)}
                </div>
            </FormContainer>

        </div>)
    }


}
